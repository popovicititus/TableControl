﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestSPA.Models
{
	public class HomeModel
	{
		public string Title { get; set; }
	}
}